MiniProject 2 - MLG Tic Tac Toe

Students: 
Marc Hegedus - 26242219
Lorenzo Monge - 40045872

Software used:
Pycharm 2021.2.2
SourceTree 3.4.5
Python 3.7.9
pypy 3.7

Run instructions:
Currently setup to run 2.6 in the handout.

Run program and enter information in the following order:
board size
number of blocs
position of blocs
winning line size
max depth for adversarial search of both players
maximum amount of time alloted for the AI
AlphaBeta or Minimax algorithm
e(1) or e(2) heuristic of both players
play mode

Github project URL:
https://github.com/mhege/COMP-472.git
