MiniProject 1

Student: Marc Hegedus - 26242219

Software used:
Pycharm 2021.2.2
SourceTree 3.4.5
Python 3.8.10

Run instructions:
Place BBC folder and drug200 in the same directory as task1.py and task2.py
Run task1.py as is, it will generate bbc-performance.txt and BBC-distribution.pdf.
Run task2.py as is, it will generate drugs-performance.txt and drug-distribution.pdf.

Discussion files:
bbc-discussion and drug-discussion were written apart and are not found in the .py files.

Github project URL:
https://github.com/mhege/COMP-472.git